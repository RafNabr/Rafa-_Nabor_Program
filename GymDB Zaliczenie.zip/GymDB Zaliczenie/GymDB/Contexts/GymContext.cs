﻿using GymDB.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace GymDB.Contexts
{
    public class GymContext : DbContext 
    {
        public GymContext()
        {

        }
        public DbSet<GymModel> GymDB { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptions)
        {
           
            dbContextOptions.UseSqlServer("Server=NT-27.WWSI.EDU.PL,1601;Database=KASETY_502_14;User Id=Z502_14;Password=ioplkj!2#;Connect Timeout=30;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        }
    }
}
