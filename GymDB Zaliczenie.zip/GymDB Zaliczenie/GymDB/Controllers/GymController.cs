﻿using GymDB.Logic;
using GymDB.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymDB.Controllers
{
    public class GymController : Controller
    {
 
        public IActionResult Index()
        {
            var manager = new GymManager();
            var equip = manager.GetEqup();
            return View(equip);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(GymModel equip)
        {
            var gymManager = new GymManager();
            gymManager.AddBook(equip);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Remove(int id)
        {
            var gymManager = new GymManager();
            var equip = gymManager.GetGym(id);
            return View(equip);
        }

        [HttpPost]
        public IActionResult RemoveConfirm(int id)
        {
            var gymManager = new GymManager();

            try
            {
                var equip = gymManager.GetGym(id);
                gymManager.RemoveBook(equip.Id);
                return RedirectToAction("Index");
            }
            catch(System.Exception)
            {
                throw;
            }
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var gymManager = new GymManager();
            var equip = gymManager.GetGym(id);
            return View(equip);
        }

  
        [HttpPost]
        public IActionResult Edit(GymModel gymModel)
        {
            var gymManager = new GymManager();
            gymManager.UpdateBook(gymModel);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var gymManager = new GymManager();
            var equip = gymManager.GetGym(id);
            return View(equip);
        }

        [HttpPost]
        public IActionResult Details()
        {
            return View();
        }





    }
}
