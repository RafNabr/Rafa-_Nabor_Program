﻿using GymDB.Contexts;
using GymDB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymDB.Logic
{
    public class GymManager
    {
        public GymManager AddBook(GymModel gymModel)
        {
            using( var context = new GymContext())
            {
                context.Add(gymModel);
                try
                {
                    context.SaveChanges();
                }
                catch(Exception)
                {
                    gymModel.Id = 0;
                    context.Add(gymModel);
                    context.SaveChanges();
                }
            }
            return this;
        }

        public GymManager RemoveBook(int Id)
        {
            using ( var context = new GymContext())
            {
                var equipment = context.GymDB.SingleOrDefault(x => x.Id == Id);
                context.Remove(equipment);
                context.SaveChanges();

            }
            return this;
        }

        public GymManager UpdateBook(GymModel gymModel)
        {
            using (var context = new GymContext())
            {
                context.Update(gymModel);
                context.SaveChanges();
            }
            return this;
        }

        

        public GymModel GetGym(int Id)
        {
            using (var context = new GymContext())
            {
                var book = context.GymDB.SingleOrDefault(x => x.Id == Id);
                return book;
            }
        }

        public List<GymModel> GetEqup()
        {
            using (var context = new GymContext())
            {
              
                    var equip = context.GymDB.ToList<GymModel>();

                    return equip;
                
                
            }
        }

       

    }
}
