﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GymDB.Models
{
    public class GymModel
    {
        
        public int Id { get; set; }

        [Display(Name = "Nazwa sprzętu")]
        public string Name { get; set; } // nazwa

        [Display(Name = "Ilość wypożyczona")]
        public int Quantity { get; set; } // ilość

        [Display(Name = "Kwota")]
        public int Amount { get; set; } // kwota

        [Display(Name = "Aktualny stan")]
        public string Condition { get; set; } // stan urządzenia 

        
    }
}
